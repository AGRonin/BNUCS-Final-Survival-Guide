# -*- coding: utf-8 -*-
"""
小技巧：
spyder是有提示功能的，一般自动出现，如没有，按Tab键
运行选中的一行或多行：F9
分块运行：#%%
注释/去掉注释：Ctrl+1
"""

a = [5,9,1,2]
print(sum(a),min(a))


b = 2
c = 5.0
print(b*c)

print([i+c for i in a])


"""强制终止程序：Ctrl+c
或者点击：stop the current command"""

while True:
    print('死循环')


'''
程序调试(1)：
查看和编辑variable explorer
'''

a = 1
b = 5.6
l = list(range(100))
t = (1,2,3)
dct = {1:'a',2:'b'}
s = {'a','b','c'}


#如何将s='d,f,a,c,b,d,g,e,a,f'中的字母进行排序，
#得到新的字符串sNew= 'a,a,b,c,d,d,e,f,f,g'
s='d,f,a,c,b,d,g,e,a,f'
lst = s.split(',')
a = lst.sort()
sNew = ','.join(a)
print(sNew)


list = [1,3,5]
k = list('abc')
print(k)


'''
程序调试(2)：
多写几个print
'''

sum1=0
for i in range(1,101):
    if i%2==0:
        sum1+=i
print(sum1)


'''
程序调试(3)：
debug
'''

#石头剪刀布游戏
import random

print ("石头剪刀布游戏，石头（1）、剪刀（2）、布（3）、退出游戏(q/Q)。")

playTime = 0
winTime = 0
lossTime = 0
evenTime = 0
player = input("你出拳： ")
computer = random.randint(1, 3) #电脑出拳，生成一个随机1-3的随机整数
while True:
    if player =='q' or 'Q':
        break
    
    player = int(player)  #转换成整数
    playTime += 1
    if player == computer:
        print ("玩家{}，电脑{}，平局".format(player, computer))
        evenTime += 1
    elif player - computer==2 or player - computer==-1:
        print ("玩家{}，电脑{}，玩家胜".format(player, computer))
        winTime += 1
    else:
        print ("玩家{}，电脑{}，玩家输".format(player, computer))
        lossTime += 1
    
    computer = random.randint(1, 3) #电脑再出拳
    player = input("你出拳： ")          

print('再见，下次玩！')



a=input('请输入一句话：')
b=a.split()
c=[]
for i in b:
    if i.isalpha():
        c.append(i)
d=len(c)
e=0
for i in range(d//2):
    if c[i]==c[d-i-1]:
        continue
    else:
        e=1
        print('这句话不是回文串')
        break
if e==0:
    print('这句话是回文串')


#通过单步调试更能理解程序的执行过程和中间结果
counts = {'小龙女':'111', '杨过':'123', '黄蓉':'456'}
i = 1
while i<=3:
    username = input('请输入账号：')
    password = input('请输入密码：')
    if username in counts and password == counts[username]:
        print('登录成功！')
        break
    print(F'输入错误，你还有{3-i}次机会！')
    i += 1
else:
    print('请24小时后再试！')
    
print('finish')



def addT(x,y):
    print('这是一个简单的函数')
    print('用于dubug演示')
    print('求两个数的和')
    return x+y


a=1
b=2
c=addT(a,b)
print('结果为：',c)
print('done')


