from flask import Flask,render_template

app = Flask(__name__)

import pandas as pd
data = pd.read_csv('豆瓣top250.csv')
data.head()
movies = []
for item in data.values:
    movie = {}
    movie['电影排名'] = item[0]
    movie['电影名称'] = item[1]
    movie['电影评分'] = item[2]
    movie['评论人数'] = item[3]
    movies.append(movie)
df = data.groupby('评分').size()
score = df.index.to_list()
num = df.values.tolist()
json_data = {}
json_data['score'] = score
json_data['num'] = num
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/movie')
def movie():
    return render_template('movie.html',movies=movies)

@app.route('/score')
def score():
    return render_template('score.html')

@app.route('/word')
def word():
    return render_template('word.html')

@app.route('/team')
def team():
    return render_template('team.html')

@app.route('/data')
def data():
    return json_data

@app.route('/chart')
def chart():
    return render_template('chart.html')

    
@app.after_request
def apply_caching(response):
    response.headers["Cache-Control"] = "no-cache"
    return response

if __name__ == '__main__':
    app.run(debug=True)